<div class="container">
    <div class="row">
        <div class="col-md-3">
            <?php
            include('./../layout/leftside.php');
            ?>
        </div>
        <div class="col-md-6">
            <?php
            include('./show.php');
            ?>
        </div>
    </div>
</div>