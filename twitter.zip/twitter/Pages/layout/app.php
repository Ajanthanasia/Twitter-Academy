<html>
<head>
    <title>
        Twitter Academy
    </title>
    <link rel="stylesheet" href="./../../scripts/css/bootstrap.min.css">
</head>
</html>