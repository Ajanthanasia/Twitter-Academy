# Twitter
## Sample application of Twitter
### Start the project in index.php